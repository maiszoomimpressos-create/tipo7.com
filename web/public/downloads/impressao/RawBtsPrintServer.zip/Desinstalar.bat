@echo off
title Remocao - RawBts PrintServer
echo ============================================================
echo   Removendo o RawBts PrintServer...
echo ============================================================
set DEST=%LOCALAPPDATA%\RawBts

taskkill /f /im PrintServer.exe >nul 2>&1

if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\RawBts PrintServer.lnk" (
    del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\RawBts PrintServer.lnk" >nul 2>&1
)

if exist "%DEST%" rmdir /s /q "%DEST%"

echo.
echo   Programa removido. O Windows tambem nao vai mais iniciar ele junto.
echo.
pause